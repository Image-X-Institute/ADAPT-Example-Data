function p3_ctdvf(dir_ct,bounds_segment,name_elastix,elastix_parfile,elastix_parfile_full)
%Computes DVFs from the 4DCT. Makes the masks too.

%dir proc contains the CT volumes
%e.g. dir_proc = 'E:\\ADAPT\\Patient_01\\ct';

%bounds_segment contains the segmentation limits (see below)

%The phase 2 CT would be at E:\\ADAPT\\Patient_01\\ct\\CT_02.mha
%The DVF will be in E:\\ADAPT\\Patient_01\\ct\\DVF
%% making masks
airlung = bounds_segment(1);
lungsoft = bounds_segment(2);
softbone = bounds_segment(3);
[info,vol] = MhaRead([dir_ct,'\\CT_06.mha']);
indx_body = vol>airlung;            %find everything more absorbing than air (so, body)
body = 0*vol; body(indx_body) = 1;
MhaWrite(info,body,[dir_ct,'\\BodyMask.mha']);
indx_lung = vol>airlung & vol<lungsoft;            %find everything more absorbing than air but less than muscle (lung)
lung = 0*vol; lung(indx_lung) = 1;
MhaWrite(info,lung,[dir_ct,'\\LungMask.mha']);
%% Compute DVFs
indx_dvf = [1,2,3,4,5,7,8,9,10];
mkdir([dir_ct,'\\elastix']);
list_ct = lscell([dir_ct,'\\CT_*.mha']);
n_ct = length(list_ct);
%% DIR between CT volumes
do_elastix = true;         %this is just here for debug
if do_elastix;
    for jj = 1:n_ct;
        if jj == 6; continue; end
        elastixRegistration(list_ct{jj},list_ct{6},[dir_ct,'\\elastix'],...
            elastix_parfile_full,[dir_ct,'\\BodyMask.mha'],...
            [dir_ct,'\\BodyMask.mha'],'',...
            false,['-labels ',dir_ct,'\\LungMask.mha'],'',...
            name_elastix);
    end
end
%% Turn DIR result into DVF (4D array (really 3 3D arrays))
mkdir([dir_ct,'\\dvf']);
list_elastix = lscell([dir_ct,'\\elastix\\CT_*',elastix_parfile,'_CT_*.txt']);
parfor jj = 1:9;
    elastixTransform(list_elastix{jj},'',true,[dir_ct,num2str(indx_dvf(jj),'\\dvf\\dvf_%02d.mha')]);
end

%% Split each DVF into 3 3D arrays
for jj = 1:9;
    name_dvf_full = [dir_ct,num2str(indx_dvf(jj),'\\dvf\\dvf_%02d')];
    [info,dvf] = MhaRead([name_dvf_full,'.mha']);
    info = rmfield(info,'ElementNumberOfChannels');
    for kk = 1:3;
        MhaWrite(info,dvf(:,:,:,kk),[name_dvf_full,num2str(kk,'_%01d.mha')]);
    end
end
%% putting a section here to delete stuff we don't need.
% Haven't decided what that is yet. Probably everything except the 27 split DVFs.

end

