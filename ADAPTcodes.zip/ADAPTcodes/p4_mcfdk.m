function p4_mcfdk(dir_proc,dirs_proj,dirs_recons,...
    do_mcfdk,dir_ct,...
    name_elastix,elastix_parfile,elastix_parfile_full);
%P1_mcfdk does the MCFDK reconstructions

%dir_proc is the patient directory e.g E:\\ADAPT\\Patient_01
%other dirs take this as a prefix (+\\)

%dirs_proj is a array containging directorys containging projections,
%e.g. {'f1_conv_proj','f1_600_proj','f1_200_proj','f2_conv_proj','f2_600_proj','f2_200_proj'};

%dirs_recons is a array of directorys to drop reconstructions into
%e.g. dirs_recons = {'f1_conv','f1_600','f1_200','f1_150','f1_100','f1_50','f2_conv','f2_600','f2_200','f2_150','f2_100','f2_50'};

%scans_mcfdk_align says which 3DFDK to align to the CT to make the MCFDK DVF
%e.g. scans_mcfdk_align = [1,2,2,2,2,2,4,5,5,5,5,5]; would make 1 DVF per
%RMG scan

%dir_ct says where the CT, and therefore DVF, is.

%scans_data is a vector reffering to which element of proj_dirs we take
%data from
%e.g. f1_50 downsamples preojections from f1_200
%e.g. scans_data = [1,2,3,2,3,3,4,5,6,5,6,6];

%do_mcfdk is a vector of which scans to do
%e.g. do_mcfdk = [do_conv_f1,do_600_f1,do_200_f1,do_150_f1,do_100_f1,do_50_f1,do_conv_f2,do_600_f2,do_200_f2,do_150_f2,do_100_f2,do_50_f2];

%scans_samplerate is a vector stating the downsampling factor for each scan
%e.g. f1_50 downsamples preojections from f1_200 at factor 4
%e.g. scans_samplerate = [1 1 1 4 2 4 1 1 1 4 2 4];

%Example phase 1 MCFDK reconstruction would be at
%E:\\ADAPT\\Patient_01\\f1_150_MCFDK\\f1_150_MCFDK_01.mha
%the prefix helps when viewing in slicer.

%%
%elastix_parfile_ct2cbct = 'Owens_Elastix_Affine_openCL';      %could make this deformable some time
%elastix_parfile_full = 'E:\Owens_Elastix\Owens_Elastix_Affine_openCL.txt';
%elastix_parfile_ct2cbct = 'Andys_Elastix_Rigid';      %could make this deformable some time
%elastix_parfile_full = 'E:\Owens_Elastix\Andys_Elastix_Rigid.txt';
elastix_parfile_ct2cbct = elastix_parfile;
elastix_parfile_full = elastix_parfile_full;
n_scans = length(do_mcfdk);
%% work through each scan
for jj = 1:n_scans
    if do_mcfdk(jj);            %check we want to do this one
        %% set names, load vars, make directorys
        dir_recon = [dir_proc,'\\',dirs_recons{1,jj},'_mcfdk'];
        dir_dvf = [dir_proc,'\\',dirs_recons{1,jj},'_mcfdk\\dvf'];
        mkdir(dir_recon);
        %% Align 3DCT to 3DFDK
        dir_fdk = [dir_proc,'\\',dirs_recons{1,jj},'_fdk'];
        mkdir(dir_dvf);
        name_3dfdk = [dir_fdk,'\\',dirs_recons{1,jj},'_3DFDK.mha'];
        %% Rigid align 3DCT to 3DFDK
        %% Note: Try making this deformable in future
        elastixRegistration([dir_ct,'\\avg.mha'],name_3dfdk,dir_dvf,...
            elastix_parfile_full,'','','',...
            false,'','',name_elastix);
        %% Find all the split DVFs and shift them
        list_dvf = lscell([dir_ct,'\\dvf\\dvf_*_*.mha']);
        for kk = 1:length(list_dvf);
            [~,name] = fileparts(list_dvf{kk});
            elastixTransform([dir_dvf,'\\avg_',elastix_parfile_ct2cbct,'_',dirs_recons{1,jj},'_3DFDK.txt'],...
                list_dvf{kk},false,...
                [dir_dvf,'\\aligned_',name,'.mha']);
        end
        %% recombine to 3D DVFs (3 by nxnxn)
        for kk = 1:10;                                                          %Shifting the CT DVF to CBCT
            if kk == 6;  continue; end
            name_dvf_3d = [dir_dvf,num2str(kk,'\\aligned_dvf_%02d')];
            clear dvf_3d;
            for ll = 1:3;
                [info,dvf_1d]=MhaRead([name_dvf_3d,num2str(ll,'_%01d.mha')]);
                dvf_3d(:,:,:,ll) = dvf_1d;
            end
            info.ElementNumberOfChannels = '3';
            MhaWrite(info,dvf_3d,...
                [dir_dvf,num2str(kk,'\\aligned_dvf_%02d.mha')]);
        end
        %% time to actually do the mcfdk
        name_fdk = [dir_proc,'\\',dirs_recons{1,jj},'_fdk\\',dirs_recons{1,jj},num2str(6,'_4DFDK_%02d.mha')];
        [info,vol_mcfdk6] = MhaRead(name_fdk);
        parfor kk = 1:10;
            if kk == 6;  continue; end
            name_fdk = [dir_proc,'\\',dirs_recons{1,jj},'_fdk\\',dirs_recons{1,jj},num2str(kk,'_4DFDK_%02d.mha')];
            system(['igttransformwithdvf -v off ',...
                ' -d ',dir_dvf,num2str(kk,'\\aligned_dvf_%02d.mha'),' ',...
                ' -i ',name_fdk,' ',...
                ' -o ',dir_dvf,'\\',dirs_recons{1,jj},num2str(kk,'_MCFDK_06_%02d.mha ')]);
            [info,vol] = MhaRead([dir_dvf,'\\',dirs_recons{1,jj},num2str(kk,'_MCFDK_06_%02d.mha ')]);
            vol_mcfdk6 = vol_mcfdk6+vol;
        end
        MhaWrite(info,vol_mcfdk6,[dir_recon,'\\',dirs_recons{1,jj},num2str(6,'_MCFDK_%02d.mha ')]);
        clear vol_mcfdk6 vol
        %% Warp to the other phases
        parfor kk = 1:10;
            if kk == 6; continue; end
            system(['igttransformwithdvf -v off -n on ',...
                ' -d ',dir_dvf,num2str(kk,'\\aligned_dvf_%02d.mha'),' ',...
                ' -i ',dir_recon,'\\',dirs_recons{1,jj},'_MCFDK_06.mha ',...
                ' -o ',dir_recon,'\\',dirs_recons{1,jj},num2str(kk,'_MCFDK_%02d.mha ')]);
        end
        rmdir(dir_dvf,'s');
        %% animating
        clear volnames;
        for kk = 1:10;
            volnames{1,kk} = [dir_recon,'\\',dirs_recons{1,jj},num2str(kk,'_MCFDK_%02d.mha ')];
        end
        gifname = [dir_recon,'\\',dirs_recons{1,jj},'_MCFDK.gif'];
        vols4D_to_gif(gifname,volnames)
    end
end
'MCFDK Done'
end