function     p6_mkbdvf(dir_proc,dirs_recons,...
    do_mkbdvf,mkb_bodyval,name_elastix,elastix_parfile,elastix_parfile_full)
%Computes DVFs from the MKB. Makes the masks too.

%dir proc - where stuff lives
%e.g. dir_proc = 'E:\\ADAPT\\Patient_01';

%dirs_recons - extension specifying each scan type

%

%bounds_segment_mkb contains the segmentation limits (see below)

%The phase 2 CT would be at E:\\ADAPT\\Patient_01\\ct\\CT_02.mha
%The DVF will be in E:\\ADAPT\\Patient_01\\ct\\DVF
%%
n_scans = length(do_mkbdvf);
for jj = 1:n_scans;
    if do_mkbdvf(jj);
        dir_mkb = [dir_proc,'\\',dirs_recons{1,jj},'_mkb'];
        dir_mcmkb = [dir_proc,'\\',dirs_recons{1,jj},'_mcmkb'];
        mkdir(dir_mcmkb);
        mkdir([dir_mcmkb,'\\dvf']);
        %% making masks
        [info,vol] = MhaRead([dir_mkb,'\\',dirs_recons{1,jj},'_3DFDK.mha']);
        indx_body = vol>mkb_bodyval;            %find everything more absorbing than air (so, body)
        body = 0*vol; body(indx_body) = 1;
        MhaWrite(info,body,[dir_mkb,'\\BodyMask.mha']);
        %% Compute DVFs
        indx_dvf = [1,2,3,4,5,7,8,9,10];
        mkdir([dir_mcmkb,'\\elastix']);
        %% DIR between MKB volumes
        do_elastix = true;         %this is just here for debug
        if do_elastix ;
            for kk = 1:10;
                if kk == 6; continue; end
                elastixRegistration([dir_mkb,'\\',dirs_recons{1,jj},num2str(kk,'_MKB_%02d.mha')],...
                    [dir_mkb,'\\',dirs_recons{1,jj},num2str(6,'_MKB_%02d.mha')],...
                    [dir_mcmkb,'\\elastix'],elastix_parfile_full,...
                    [dir_mkb,'\\BodyMask.mha'],[dir_mkb,'\\BodyMask.mha'],...
                    '',false,'','',name_elastix);
            end
        end
        %% Turn DIR result into DVF (4D array (really 3 3D arrays))
        list_elastix = lscell([dir_mcmkb,'\\elastix\\',dirs_recons{1,jj},'_MKB_*',elastix_parfile,'_',dirs_recons{1,jj},'_MKB_*.txt']);
        for kk = 1:9;
            elastixTransform(list_elastix{kk},'',true,[dir_mcmkb,num2str(indx_dvf(kk),'\\dvf\\dvf_%02d.mha')]);
        end
    rmdir([dir_mcmkb,'\\elastix'],'s');
    end
end

end

