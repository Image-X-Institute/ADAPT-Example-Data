function  p1_process(dir_raw,dir_proc,dir_raw_ct,dirs_raw_cbct,dirs_proj,...  
	do_ct,do_raw_scans,scans_conv);
%P1_PROCESS takes raw patient file (CT, conv + 600 + 200 CBCT) and makes
%tidy processed patient file
mkdir(dir_proc);        %make somewhere to put processed stuff!
%%
n_cbct = length(dirs_proj);
%% process the CT
if do_ct;
    dir_ct = [dir_proc,'\\ct'];     %CT goes here
    mkdir(dir_ct);
    list_raw_ct = lscell([dir_raw_ct,'\\*']);
    names_rctdirs = {'_0%','_10%','_20%','_30%','_40%','_50%','_60%',...
        '_70%','_80%','_90%'};        %convention used for this 4D CT
    reorder = [6 7 8 9 10 1 2 3 4 5];                       %our phase and their phase is different
    for jj = 1:10;
        clear vol volpos;
        indx = contains(list_raw_ct,names_rctdirs{1,jj});
        dirname = list_raw_ct{indx};                        %directory with current phase 4DCT slices
        list_ct_slices = lscell([dirname,'\\*.dcm']);       %slice file names
        n_slices = length(list_ct_slices);                  %number of slices
        for kk = 1:n_slices;
            info = dicominfo(list_ct_slices{1,kk});         %info of this slice
            slice = dicomread(list_ct_slices{1,kk});        %the slice
            vol(:,:,kk) = slice;                            %build the volume
            volpos(:,kk) = info.ImagePositionPatient;             %the actual location of each slice
        end
        [volpos,indx] = sort(volpos(3,:));                  %sort the slices
        vol = vol(:,:,indx);                                %sort the volume
        dims_vol = size(vol);
        %% This is the old resize - seems to be right
        dims_vol(3) = 2*dims_vol(3); 
        dims_vol(1) = dims_vol(1)*1.18715; 
        dims_vol(2) = dims_vol(2)*1.18715;
        %% Think it should be this though? But it makes the CT too big
        %dims_vol(3) = dims_vol(3)*info.SliceThickness;
        %psize = info.PixelSpacing;
        %dims_vol(1:2) = dims_vol(1)*psize(1); dims_vol(2) = dims_vol(2)*psize(2);
        %%
        vol = imresize3(vol,dims_vol);
        vol = flipud(vol);
        vol = permute(vol,[2,3,1]);
        vol = fliplr(vol);
        dims_vol = size(vol);
        load mhaHeaderTemplate.mat;
        mhahead = mhaHeaderTemplate;
        mhahead.PixelDimensions = [1,1,1];
        mhahead.Dimensions = dims_vol;
        mhahead.Offset = -0.5*dims_vol.*[1,1,1];
        MhaWrite(mhahead,vol,[dir_ct,num2str(reorder(jj),'\\CT_%02d.mha')]);
        if jj == 1;
            avg = 0.1*vol;
        else
            avg = avg+0.1*vol;
            
        end
    end
    MhaWrite(mhahead,avg,[dir_ct,'\\avg.mha']);
end
%% process CBCT
for jj = 1:n_cbct
    if do_raw_scans(jj);
        clear ang angs g G Pmat Pmats P
        list_proj = lscell([dirs_raw_cbct{1,jj},'\\*.his']);    %all the projections
        dirname = [dir_proc,'\\',dirs_proj{1,jj}];  %geometry file and matdata goes here
        mkdir(dirname);
        mkdir([dirname,'\\his']);
        if scans_conv(jj);
            xvi_sort = lscell([dirs_raw_cbct{1,jj},'\\Reconstruction\\*Sort*']);    %filename of the xvi sort file
            xvi_sort = readtable(xvi_sort{1,1});                        %opening the file
            bin = xvi_sort.Var4;                 %what XVI says the phase is. Same as us!
            bin = bin+1;
            np = length(bin);
            frames = parseXML([dirs_raw_cbct{1,jj},'\\_Frames.xml']);          %pulling gantry angles from "frames"
            frames = frames.Children(14).Children([2:2:end]);
            for kk = 1:np;
                ang = frames(kk).Children(10).Children.Data;
                angs(kk) = str2num(ang);
            end
            angs = angs+360+90;
            angs(angs>360) = angs(angs>360)-360;
        else
            angs = csvread([dirs_raw_cbct{1,jj},'\\angles.csv']);
            bin = csvread([dirs_raw_cbct{1,jj},'\\sortfile.csv']);
        end
        np = length(bin);
        indx_goodproj = bin~=0;
        num_goodproj = [1:np];
        num_goodproj = num_goodproj(indx_goodproj);
        bin = bin(indx_goodproj);
        angs = angs(indx_goodproj);
        np = length(bin);
        for kk = 1:np;
            G(:,kk) = [angs(kk);0;0;0;0;0;0;1000;1536];
            Pmats(:,:,kk) = gtop(G(:,kk));
            [info,p] = HisRead(list_proj{1,num_goodproj(kk)});
            HisWrite(info,p,[dirname,num2str(kk,'\\his\\Proj_%05d.his')]);
        end
        WriteRTKGeometryXML(Pmats,[dirname,'\\Geometry.xml']);
        bin = bin(:);       %make sure they are columns!
        angs = angs(:);
        save([dirname,'\\matdata.mat'],'bin','angs','G','Pmats');
    end
end
   


end 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
