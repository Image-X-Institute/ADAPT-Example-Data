function [P] = gtop(g)
%Takes physically meaningful parameters g to make projection matrix P
%% the P part

GantryAngle = g(1);OutOfPlaneAngle=g(2);InPlaneAngle=g(3);SourceOffsetX=g(4);SourceOffsetY=g(5);DetOffsetX=g(6);DetOffsetY=g(7);SID=g(8);SDD=g(9);

GA = GantryAngle*((2*pi)/(360));                 
OPA = OutOfPlaneAngle*((2*pi)/(360));              
IPA = InPlaneAngle*((2*pi)/(360)); 
SOX = SourceOffsetX;
SOY = SourceOffsetY;
DOX = DetOffsetX;
DOY = DetOffsetY;

%% 
% R1 = [cos(-IPA),-sin(-IPA),0,0;sin(-IPA),cos(-IPA),0,0;0,0,1,0;0,0,0,1];
% R2 = [1,0,0,0;0,cos(-OPA),-sin(-OPA),0;0,sin(-OPA),cos(-OPA),0;0,0,0,1];
% R3 = [cos(-GA),0,sin(-GA),0;0,1,0,0;-sin(-GA),0,cos(-GA),0;0,0,0,1];
% 
% S1 = [1,0,SOX-DOX;0,1,SOY-DOY;0,0,1];
% S2 = [-SID,0,0,0;0,-SID,0,0;0,0,1,-SID];
% S3 = [1,0,0,-SOX;0,1,0,-SOY;0,0,1,0;0,0,0,1];
%
% P = S1*S2*S3*R1*R2*R3;

P = [   [ - sin(GA)*(cos(OPA)*(DOX - SOX) + SDD*sin(IPA)*sin(OPA)) - SDD*cos(GA)*cos(IPA), sin(OPA)*(DOX - SOX) - SDD*cos(OPA)*sin(IPA),   SDD*cos(IPA)*sin(GA) - cos(GA)*(cos(OPA)*(DOX - SOX) + SDD*sin(IPA)*sin(OPA)), SDD*SOX + SID*(DOX - SOX)];...
        [   SDD*cos(GA)*sin(IPA) - sin(GA)*(cos(OPA)*(DOY - SOY) + SDD*cos(IPA)*sin(OPA)), sin(OPA)*(DOY - SOY) - SDD*cos(IPA)*cos(OPA), - cos(GA)*(cos(OPA)*(DOY - SOY) + SDD*cos(IPA)*sin(OPA)) - SDD*sin(GA)*sin(IPA), SDD*SOY + SID*(DOY - SOY)];...
        [                                                                cos(OPA)*sin(GA),                                    -sin(OPA),                                                                cos(GA)*cos(OPA),                      -SID]];
 








