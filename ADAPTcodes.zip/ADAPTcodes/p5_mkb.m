function p5_mkb(dir_proc,dirs_proj,dirs_recons,...
    do_mkb,...
    scans_data,scans_samplerate);
%P1_FDK does the FDK reconstructions

%dir_proc is the patient directory e.g E:\\ADAPT\\Patient_01
%other dirs take this as a prefix (+\\)

%dirs_proj is a array containging directorys containging projections,
%e.g. {'f1_conv_proj','f1_600_proj','f1_200_proj','f2_conv_proj','f2_600_proj','f2_200_proj'};

%dirs_recons is a array of directorys to drop reconstructions into
%e.g. dirs_recons = {'f1_conv','f1_600','f1_200','f1_150','f1_100','f1_50','f2_conv','f2_600','f2_200','f2_150','f2_100','f2_50'};

%scans_data is a vector reffering to which element of proj_dirs we take
%data from
%e.g. f1_50 downsamples preojections from f1_200
%e.g. scans_data = [1,2,3,2,3,3,4,5,6,5,6,6];

%do_mkb is a vector of which scans to do

%scans_samplerate is a vector stating the downsampling factor for each scan
%e.g. f1_50 downsamples preojections from f1_200 at factor 4
%e.g. scans_samplerate = [1 1 1 4 2 4 1 1 1 4 2 4];

%Example phase 1 MKB reconstruction of RMG 200 would be at
%E:\\ADAPT\\Patient_01\\f1_200_mkb\\f1_conv_mkb_01.mha
%the prefix helps when viewing in slicer.

%%
n_scans = length(do_mkb);
for jj = 1:n_scans
    if do_mkb(jj);            %check we want to do this one
        %% set names, load vars, make directorys
        dir_recon = [dir_proc,'\\',dirs_recons{1,jj},'_mkb'];
        dir_proj = [dir_proc,'\\',dirs_proj{1,scans_data(jj)}];
        load([dir_proj,'\\matdata.mat']);
        n_proj = length(bin);
        mkdir(dir_recon);
        %% downsampling
        sort = [ones(10,1);zeros(10*(scans_samplerate(jj)-1),1)];
        sort = repmat(sort,ceil(1+n_proj/(10+10*(scans_samplerate(jj)-1))),1);
        sort = sort(1:n_proj);
        sort(n_proj-9:n_proj) = 1;  %make sure we have the last couple projections
        sort = logical(sort);
        bin = bin.*sort;            %makes cut projections zero
        angs = angs.*sort;
        %% 3DFDK
        csvwrite([dir_recon,'\\sort.csv'],sort(:));
        %% make a 3DFDK input. Why not.
        system(['rtkfdk ',...
            ' -s ',dir_recon,'\\sort.csv ',...
            ' -o ',dir_recon,'\\',dirs_recons{1,jj},'_3DFDK.mha ',...
            ' -p ',dir_proj,'\\his ',...
            ' -r his ',...
            ' -g ',dir_proj,'\\Geometry.xml ',...
            ' --hardware cuda ',...
            ' --dimension 270,270,270 --spacing 1',...
            ' --hann 0.9 --pad 10']);
        for kk = 1:10;
            sort = bin==kk;
            csvwrite([dir_recon,'\\sort.csv'],sort(:));
            system(['rtkmkb ',...
                ' -i ',dir_recon,'\\',dirs_recons{1,jj},'_3DFDK.mha ',...
                ' -s ',dir_recon,'\\sort.csv ',...
                ' -o ',dir_recon,'\\',dirs_recons{1,jj},num2str(kk,'_MKB_%02d.mha '),...
                ' -p ',dir_proj,'\\his ',...
                ' -r his ',...
                ' -g ',dir_proj,'\\Geometry.xml ',...
                ' --hardware cuda ',...
                ' --dimension 270,270,270 --spacing 1',...
                ' --hann 0.9 --pad 10']);
        end
        %% animating
        clear volnames;
        for kk = 1:10;
            volnames{1,kk} = [dir_recon,'\\',dirs_recons{1,jj},num2str(kk,'_MKB_%02d.mha ')];
        end
        gifname = [dir_recon,'\\',dirs_recons{1,jj},'_MKB.gif'];
        vols4D_to_gif(gifname,volnames)
    end
end
'MKB Done'
end