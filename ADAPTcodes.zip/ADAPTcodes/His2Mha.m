close all; clear all;
dir_change = 'E:\Owen\ADAPT\Patient_01\f1_200_proj';
do_writeraw = true;
do_writeatt = true;

%%
names_his = lscell([dir_change,'\\his\\*.his']);
[info_his,p_his] = HisRead(names_his{1,1});
n_proj = length(names_his);
load MhaHeaderTemplate;
info_mha = mhaHeaderTemplate;
info_mha.PixelDimensions = [info_his.PixelSpacingX,info_his.PixelSpacingY,1];
info_mha.Offset = [info_his.OriginX,info_his.OriginY,1];
info_mha.Dimensions = [info_his.SizeX,info_his.SizeY,n_proj];
for jj = 1:n_proj;
    [info_his,p_his] = HisRead(names_his{1,jj});
    P(:,:,jj) = p_his;
end
%%
if do_writeraw;
    MhaWrite(info_mha,P,[dir_change,'\\proj.mha']);
end
%% convert to attenuation image
if do_writeatt;

end
