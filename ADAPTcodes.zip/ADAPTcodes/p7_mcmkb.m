function p7_mcmkb(dir_proc,dirs_proj,dirs_recons,...
    do_mcmkb,dir_ct);
%p7_mcmkb does the MCFDK reconstructions.
%This version warps mkb volumes. not convinced this is better than warping
%4DFDK volumes.

%%
n_scans = length(do_mcmkb);
%% work through each scan
for jj = 1:n_scans
    if do_mcmkb(jj);            %check we want to do this one
        %% set names, load vars, make directorys
        dir_recon = [dir_proc,'\\',dirs_recons{1,jj},'_mcmkb'];
        dir_dvf = [dir_proc,'\\',dirs_recons{1,jj},'_mcmkb\\dvf'];
        mkdir(dir_recon);
        %% time to actually do the mcfdk
        name_mkb = [dir_proc,'\\',dirs_recons{1,jj},'_mkb\\',dirs_recons{1,jj},num2str(6,'_MKB_%02d.mha')];
        [info,vol_mcmkb6] = MhaRead(name_mkb);
        parfor kk = 1:10;
            if kk == 6;  continue; end
            name_mkb = [dir_proc,'\\',dirs_recons{1,jj},'_mkb\\',dirs_recons{1,jj},num2str(kk,'_MKB_%02d.mha')];
            system(['igttransformwithdvf -v off ',...
                ' -d ',dir_dvf,num2str(kk,'\\dvf_%02d.mha'),' ',...
                ' -i ',name_mkb,' ',...
                ' -o ',dir_dvf,'\\',dirs_recons{1,jj},num2str(kk,'_MCMKB_06_%02d.mha ')]);
            [info,vol] = MhaRead([dir_dvf,'\\',dirs_recons{1,jj},num2str(kk,'_MCMKB_06_%02d.mha ')]);
            vol_mcmkb6 = vol_mcmkb6+vol;
        end
        MhaWrite(info,vol_mcmkb6,[dir_recon,'\\',dirs_recons{1,jj},num2str(6,'_MCMKB_%02d.mha ')]);
        clear vol_mcfdk6 vol
        %% Warp to the other phases
        parfor kk = 1:10;
            if kk == 6; continue; end
            system(['igttransformwithdvf -v off -n on ',...
                ' -d ',dir_dvf,num2str(kk,'\\dvf_%02d.mha'),' ',...
                ' -i ',dir_recon,'\\',dirs_recons{1,jj},'_MCMKB_06.mha ',...
                ' -o ',dir_recon,'\\',dirs_recons{1,jj},num2str(kk,'_MCMKB_%02d.mha ')]);
        end
        %rmdir(dir_dvf,'s');
        %% animating
        clear volnames;
        for kk = 1:10;
            volnames{1,kk} = [dir_recon,'\\',dirs_recons{1,jj},num2str(kk,'_MCMKB_%02d.mha ')];
        end
        gifname = [dir_recon,'\\',dirs_recons{1,jj},'_MCMKB.gif'];
        vols4D_to_gif(gifname,volnames)
    end
end
'MCMKB Done'
end