close all; clear all;
%hi
%% Settings - top level
do_p1_process =  false;      %Reads in the raw projections and writes to a tidy processed folder.
do_p2_fdk =      false;          %Does 3DFDK and 4DFDK reconstructions of conventional, 600, 200, 150, 100 and 50 RMG proj scans.
do_p3_ctdvf =    false;        %Do DIR on the 4DCT to get DVFs for MCFDK. Note that these will not be aligned. This is by far the most computationally expensive part.
do_p4_mcfdk =    false;        %does MCFDK. Note: option to use 1 RMG aligned DVF per fraction
do_p5_mkb =      false;          %similar to p2 but does mkb
do_p6_mkbdvf =   false;       %Do DIR on corresponding MKB recon.
do_p7_mcmkb =    false;        %does MCMKB
%% processed Directorys
dir_proc = 'E:\Owen\ADAPT\\Patient_09_test';
%% Raw directorys
dir_raw = 'Z:\GRP-RPL\2RESEARCH\1_ClinicalData\ADAPT\Raw Patient Data\Patient_09';
dir_raw_ct = 'Z:\GRP-RPL\2RESEARCH\1_ClinicalData\ADAPT\Raw Patient Data\Patient_09\Planning Data\2020-01__Studies';
dir_raw_conv_f1 = 'Z:\GRP-RPL\2RESEARCH\1_ClinicalData\ADAPT\Raw Patient Data\Patient_09\Fraction_01\Conventional\img_1.3.46.423632.33640220202114465855.110';
dir_raw_600_f1 = 'Z:\GRP-RPL\2RESEARCH\1_ClinicalData\ADAPT\Raw Patient Data\Patient_09\Fraction_01\High quality\img_1.3.46.423632.33640220202115420682.118\Reconstruction\All';
dir_raw_200_f1 = 'Z:\GRP-RPL\2RESEARCH\1_ClinicalData\ADAPT\Raw Patient Data\Patient_09\Fraction_01\Fast\img_1.3.46.423632.33640220202115132387.117\Reconstruction\All';
dir_raw_conv_f2 = '';
dir_raw_600_f2 = '';
dir_raw_200_f2 = '';
%% which scans to do
do_conv_f1 =true;
do_600_f1 = true;
do_310_f1 = true;
do_200_f1 = true;
do_160_f1 = true&do_600_f1;     %we use the data from 600 to do this
do_110_f1 = true&do_200_f1;     %we use the data from 200 to do this
do_60_f1 =  true&do_200_f1;     %we use the data from 200 to do this
do_conv_f2 =false;
do_600_f2 = false;
do_310_f2 = false;
do_200_f2 = false;
do_160_f2 = true&do_600_f2;
do_110_f2 = true&do_200_f2;
do_60_f2 =  true&do_200_f2;
%% The above settings but saved a bit more compactly and some useful outputs
dirs_proj = {'f1_conv_proj','f1_600_proj','f1_200_proj','f2_conv_proj','f2_600_proj','f2_200_proj'};
dirs_recons = {'f1_conv','f1_600','f1_310','f1_200','f1_160','f1_110','f1_60',...
    'f2_conv','f2_600','f2_310','f2_200','f2_160','f2_110','f2_60'};
do_scans = [do_conv_f1,do_600_f1,do_310_f1,do_200_f1,do_160_f1,do_110_f1,do_60_f1,...
    do_conv_f2,do_600_f2,do_310_f2,do_200_f2,do_160_f2,do_110_f2,do_60_f2];
dir_ct = [dir_proc,'\\ct'];
scans_conv = [true false false false false false false true false false false false false false];  %which scans are conventional
%% For down sampling
scans_samplerate = [1 1 2 1 4 2 4 1 1 2 1 4 2 4];               %downsampling rate
scans_data = [1,2,2,3,2,3,3,4,5,5,6,5,6,6];   %what scan the data comes from, relative to dirs_proj
%% Which scans to reconstruct (in order of "scans to do")
do_ct =     true;
do_fdk = true&do_scans;     %i.e. we do every scan available
do_mcfdk = [false true true true true true true false true true true true true true];
do_mcfdk = do_mcfdk&do_scans;
do_mkb = do_mcfdk;
do_mkbdvf = do_mkb;
do_mcmkb = do_mkb;
do_smeir = [false false false true false false false false false false false false false false];
%% locations of things
name_elastix = 'H:\Owens_Elastix\x64_v4.8\elastix.exe';                         %where the elastix .exe lives
elastix_parfile_ct = 'Andys_Elastix_BSpline_Sliding';   %The parameter file for CT DIR
elastix_parfile_full_ct = 'H:\Owens_Elastix\Andys_Elastix_BSpline_Sliding.txt'; 
elastix_parfile_mkb = 'Owens_Elastix_BSpline_OpenCL';   %The parameter file for MKB DIR
elastix_parfile_full_mkb = 'H:\Owens_Elastix\Owens_Elastix_BSpline_OpenCL.txt';
elastix_parfile_rigid = 'Andys_Elastix_Rigid';
elastix_parfile_rigid_full = 'H:\Owens_Elastix\Andys_Elastix_Rigid.txt';
%% Running through the codes

%%
if do_p1_process;
    scans_raw_conv = [true false false true false false];   %is it a conventional scan? handles a little differently
    dirs_raw_cbct = {dir_raw_conv_f1,dir_raw_600_f1,dir_raw_200_f1,dir_raw_conv_f2,dir_raw_600_f2,dir_raw_200_f2};
    do_raw_scans = [do_conv_f1,do_600_f1,do_200_f1,do_conv_f2,do_600_f2,do_200_f2];
    p1_process(dir_raw,dir_proc,dir_raw_ct,dirs_raw_cbct,dirs_proj,...
        do_ct,do_raw_scans,scans_raw_conv);
end
%%
if do_p2_fdk;
    p2_fdk(dir_proc,dirs_proj,dirs_recons,...
    do_fdk,...
    scans_data,scans_samplerate);
end
%%
if do_p3_ctdvf;
    airlung = 140;
    lungsoft = 880;
    softbone = 1150;
    bounds_segment_ct = [airlung,lungsoft,softbone];       %cut-offs for histogram segmentation
    p3_ctdvf(dir_ct,bounds_segment_ct,name_elastix,elastix_parfile_ct,elastix_parfile_full_ct);
end
%% 
if do_p4_mcfdk;
    p4_mcfdk(dir_proc,dirs_proj,dirs_recons,...
        do_mcfdk,dir_ct,...
        name_elastix,elastix_parfile_rigid,elastix_parfile_rigid_full);
end

%%
if do_p5_mkb;
    p5_mkb(dir_proc,dirs_proj,dirs_recons,...
    do_mkb,...
    scans_data,scans_samplerate);
end
%% 
if do_p6_mkbdvf;
    mkb_bodyval = 0.0007;
    p6_mkbdvf(dir_proc,dirs_recons,...
    do_mkbdvf,mkb_bodyval,...
    name_elastix,elastix_parfile_mkb,elastix_parfile_full_mkb);
end

%%
if do_p7_mcmkb;
    p7_mcmkb(dir_proc,dirs_proj,dirs_recons,...
        do_mcmkb,dir_ct);
end













